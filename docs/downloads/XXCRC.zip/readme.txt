Josh's Misc Extension Collection
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Use at your own risk, most of these plugins are for MMF1.5.
I will include as much detail as possible on how to use each one in the archive (if not self explatory)

www.syntesis.ath.cx
www.acoders.com

Made by Josh Whelchel

Archive
-=-=-=-

--------------------------------
Xtra Xtra CRC - 11/23/02
Make sure to Open File before using any other exp or act.
Set File Att works like this : 
"RH" (read only + hidden) "R!H" (Read only NOT hidden) 
"!RH" (NOT read only + YES hidden) "!R!H" (Not Readonly nor Hidden)
--------------------------------