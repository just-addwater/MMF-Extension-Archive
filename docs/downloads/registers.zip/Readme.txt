				Mokhtar M. Khorshid's Registers Object
				=================================
Table Of Contents
-----------------
A. Purpose
B. Compatibility
C. Credits
D. About
E. Updates

A. Purpose
---------
This object writes and reads to and from the CPU registers and allows interrupt calls. 

B. Compatibility
----------------
1.The Games Factory
Copy Registers.gox to your TGF folder.

2.Click & Create
Copy Registers.cox to your CNC folder.

3.Multimedia Fusion
Copy Registers.cox to your MMF 'Programs\data\runtime\' folder, and also your MMF 'Programs\Extensions\' folder.

C. Credits
----------
If you used this object in a project please consider giving me credits.

D. About
--------
Created by Mokhtar M. Khorshid of Thunder Power
01/03/00: First version released (1.03)

E. Updates
----------
01/1/2001: MMF conversion by Tim Baker.