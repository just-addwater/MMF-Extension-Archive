
The Transparency Changer Object is Copyright
1999-2000 Michel Plante.

IMPORTANT NOTE:
______________

Remember that you must have an object selected by the 
Transparency Changer Object before attempting to change,
compare or retreive his transparency value. Otherwhise
the application can crash.
______________


The Transparency Changer Object allow you to change the
semi-transparency value of an object using a numeric value
for 0 (opaque) to 128 (completely transparent).


You must select the object first using the appropriate action,
then change his transparency value.

You can also retreive and compare the transparency value.


Possible Bug:

I don't know why, but when i try to compare the transparacy with 0
like "Transp = 0" the condition is not execute in MMF.. Weird...

Contact me:
___________
smmp@videotron.ca
http://pages.infinit.net/smmp

