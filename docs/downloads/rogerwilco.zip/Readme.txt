/*
 * Send a command string to Roger Wilco.
 *
 * Command syntax summary:
 *      arguments in [square brackets] are optional
 *      arg1|arg2|arg3  : alternatives
 *
 * Mark1 and later:
 *  /create [name|DEFAULT [password]]
 *  /join machine [name|DEFAULT [password]]
 *  /leave [channelname]
 *  /file filename.rwc
 *
 *    Note: for all channel names, use "default" to refer to the default,
 *     un-named channel.
 *
 * Mark1a and later:
 *  /callsign usercallsign
 *  /netspeed N				N between 2 (slow modem) and 50 (T1 connection)
 *  /key KEY				E.G. SPACE or CONTROL, press-to-talk key
 *  /clicks on|off|yes|no
 *  /volume N				N between 1 (almost silent) and 255
 *  /priority high|low
 *  /join1 machine[/name [password]]   e.g. /join1 www.myhost.com/channel sesame
 *
 */
