           ZipIt & UnzipIt Objects for MMF 
----------------------------------------------------
        � Copyright 1999 GIF Sistemas, c.a.
		All Rights Reserved.
		 Caracas, Venezuela.
----------------------------------------------------
       INSTALLING ZIPIT & UNZIPIT OBJECTS
----------------------------------------------------

What's in the Zip?

1. ZIPTEST.ZIP
2. UNZIPIT.COX
2.   ZIPIT.COX
3. ZIPREAD.TXT
4.   UNZIP.CCA

To install the UNZIPIT AND ZIPIT Objects follow these simple steps:

1. Unzip all files *.COX to the Programs\Extensions folder located
in your IMSI Multimedia Fusion directory.

2. Unzip all files *.COX to the Data\Runtime folder located in your
IMSI Multimedia Fusion direcotry.

===================================================================
                        CONDITIONS OF USE
===================================================================
A.- The use of ZipIt & UnzipIt Objects is subject to the following
    terms and conditions.

B.- ZIPIT & UNZIPIT OBJECTS ARE DISTRIBUTED "AS IS". NO WARRANTY OF ANY
    KIND IS EXPRESSED OR IMPLIED.  YOU USE AT YOUR OWN RISK. THE AUTHOR
    WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY 
    OTHER KIND OF LOSS WHILE USING OR MISUSING THIS SOFTWARE.


C.- You are specifically prohibited from charging, or requesting
    donations, for any such copies, however made; and from
    distributing the software and/or documentation with other
    pack of products (commercial or otherwise) without prior written
    permission. Contact Fernando Vivolo at gif@etheron.net for more
    informations ...


Enjoy them .....

Fernando Vivolo
gif@etheron.net