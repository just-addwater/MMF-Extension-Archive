
	FlashBeep v0.8
	==============

FlashBeep is a small extension which lets you make several beep sounds  (including the PC speaker beep). In this version, the extra window flash actions are not available. I cannot find a way to access the Windows API function for this (the function is FlashWindowEx, but it isn't in Visual C++ 6). The flash actions that are enabled don't actually work, but they should. I have absolutely no idea how to make them work. If you do, please email me and I'll complete the object.

Created by Chris Branch in May 2003.
email: chris.branch@starfishgames.co.uk
visit http://www.starfishgames.co.uk for more extensions and other useful things.