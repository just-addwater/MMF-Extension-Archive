System Info Object
------------------
By Mark Beazley
markb@gethyper.co.uk
------------------

About
-----
Ok this is my first extension I have realeased, it lets you get sytem folder paths in some information about the system.

To install
----------
Copy SystemInfo.cox in the Extensions folder to the
<MMFDir>\Programs\Extensions\
folder, THen copy the SystemInfo.cox file in the Runtime folder to the
<MMFDir>\Programs\Data\Runtime\
folder.

OS Return strings
-----------------
System info returns the following OS Strings

Opertaing System installed | Return String
------------------------------------------
 Windows NT                | Microsoft Windows NT
 Windows 2000   	   | Microsoft Windows 2000 
 Windows XP                | Microsoft Windows XP 
 Windows 95                | Microsoft Windows 95 
 Windows 98		   | Microsoft Windows 98 
 Windows 98 SE		   | Microsoft Windows 98 SE 
 Windows ME		   | Microsoft Windows Me 
 Windows 3.1 *		   | Microsoft Win32s 

*I am not entirely sure if this is true. Wins32 was a win 3.1 app so I have based my guess on this.

Bugs
----
I think I have got all the bugs out but if you find any problems email me at
markb@gethyper.co.uk