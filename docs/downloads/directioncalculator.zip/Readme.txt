Welcome to the Direction Calculator version 1.2 (MMF) / 1.1 (CNC/TGF) Readme file.

What's version 1.2 do?

Version 1.2 for MMF fixes a bug in the "Add a Directional Speed
to an Object" action, however it does not work very well with
games created using an older version of the extension. If MMF
crashes when you're running a game created for an older
version of the Direction Calculator just delete all the "Add a
Directional Speed to an Object" actions and reinsert them.

Contacting Me

I appreciate all the comments, questions, or bug reports you
send me. Email me at: philipwilliams@iname.com or visit my
web page at: www.mint.net/~jkenwms/cnc/
