-----------------------------
Datastore object 2.0
        by Rodrigo Braz Monteiro
	 & Marcello Bast�a-Forte
-----------------------------

Installation:

* Click & Create/Multimedia Fusion Express
	Copy kcstore.cox from the cnc32 directory to your C&C directory
	
* The Games Factory v1.05+
	Copy gfstore.gox from the tgf32 directory to your TGF directory
	
* Multimedia Fusion
	Copy kcstore.cox from the mmf32 directory to your MMFusion\Program\Extensions directory
	Copy kcstore.cox from the mmf32 directory to your MMFusion\Data\Runtime directory

-----------------------------
http://www.cellosoft.com/
http://www.cellosoft.com/extensions/
http://zeratul.cellosoft.com/
http://marcello.cellosoft.com/
zeratul@cellosoft.com
marcello@cellosoft.com
-----------------------------