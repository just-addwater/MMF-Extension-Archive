\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

   MULTIMEDIA FUSION 1.5 - BONUS PACK

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


Hi, here's a pack of extensions wich only registered users can get. I've get the files and I've packed them. In order to install it, unpack on the Programs folder of you MMF.

-Enjoy!