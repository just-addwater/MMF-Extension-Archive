Base Converter -v0.4
---------------------------

UPDATE:
Four new features have now been added!!

Convert string to ascii code (HEX)
Convert ascii to string code (HEX)

Convert string to ascii code (BINARY)
Convert ascii to string code (BINARY)

This object will simply overwrite any previouse versions.

---------------------------
Created by Christopher Lightfoot
chris@nemonix.fsnet.co.uk

Nemonix Software
http://www.nemonix.fsnet.co.uk
---------------------------
