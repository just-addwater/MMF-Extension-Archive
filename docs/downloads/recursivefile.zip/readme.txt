Recursive File Object
Version 1.2
by Dave Sanborn
(dsanborn@iname.com)

DESCRIPTION

The Recursive File Object is an extension for Multimedia Fusion which
makes up for functionality that the standard File Object seems to be
lacking: the ability to copy and delete entire directory tree structures.
With this extension, you can now accomplish with one action what it once
took pages of MMF event loops to do.

INSTALLATION

To install, simply extract the RecFile.cox file to a temporary directory,
and copy it to both the Programs/Data/Runtime directory, and the 
Programs/Extensions directory, which are both under your main MMF 
directory. You may extract the MMF demo application to any directory you
choose.

EXPRESSIONS

	Last Error - Use this expression to return the Win32 API error code
	of the last error that occurred while performing an operation with
	the object. You may retrieve a list of Win32 error codes and their
	meanings from the Microsoft web site. As of this writing, the
	following URL will take you directly to the list:

	http://msdn.microsoft.com/library/psdk/psdkref/errlist_9usz.htm

CONDITIONS

	Is the last triggered action complete? -- Use this condition to test
	for the end of an operation. Because MMF continues processing your
	application's events after triggering an action associated with this
	object, you should be EXTREMELY sure that the action is complete before
	performing ANY OTHER operations which might access the file system.
	Actions associated with this object will not trigger if another action
	associated with the object is already running, but the same DOES NOT hold
	true for the File Object that comes with MMF. A common mistake might be
	to use the Recursive File Object to copy a directory, and then use the
	MMF File Object to set the current directory to it, without first using
	this condition to make sure that the copy operation was completed. Also
	note that if an error occurs, this condition will still indicate that
	the triggered action was completed. You need to use the Last Error
	expression in tandem with this condition to ensure that your file system
	operations go smoothly.

ACTIONS

	Recursive Copy (Action) -- Use the Recursive Copy action to
	duplicate an entire directory structure. You'll be asked for the
	complete path to the directory that you want to duplicate, and then
	the complete path for the directory that you want to copy to. All
	files and sub-directories (as well as the files and sub-direct-
	ories beneath those, etc.) in the source directory will be copied
	to the new directory. If you choose an already existing directory
	as the target, all duplicate files will be overwritten.

	Recursive Delete (Action) -- Use the Recursive Delete action to
	delete a directory (and thus EVERYTHING under it; all files, sub-
	directories, files and sub-directories within those sub-directories,
	etc.) You'll be asked for the complete path to the directory
	that you want to remove.

	Rename Directory (Action) -- This action allows you to rename a
	directory. The first argument must be the complete path to the
	directory that you want to rename, but the second argument (the
	new name for the directory) can be either a complete pathname,
	or a relative pathname (relative to the parent directory of the
	directory you want to rename).


FEEDBACK & BUG REPORTS
Want to give me an "attaboy"? Want to tell me that I suck? Have some
suggestions for the extension, or maybe just some bugs to report? You can
send it all to 'dsanborn@iname.com', making sure that you put "Recursive
File Object" somewhere in the subject of your message.

DONATIONWARE
The Recursive File Object is donationware. You're completely free to use
it in both commercial and non-commercial programs, but if you do, I ask
that you do some good in the world and make a donation to your favorite
charity. If you don't have a favorite charity, mine happens to be the
National Kidney Foundation (http://www.kidney.org) and I would urge you
to donate to them.

CHANGES SINCE 0.90 BETA

	-- Added the "Are all tasks completed?" condition.
	-- Added the "Rename Directory" action.

CHANGES SINCE 1.0 RELEASE

	-- Actions no longer 'block', but instead use the internal
	HandleRunData function to ensure that MMF will keep running as file
	operations occur in the background.
	-- Added the 'Last Error' expression.

CHANGES SINCE 1.1 RELEASE

	-- Fixed a bug where directories containing files with the
	read-only attribute set, couldn't be recursively deleted.
	-- Fixed a bug in the demo which only allowed users to enter
	filenames as long as the entry boxes themselves.

LEGAL STUFF
This software is provided as is, with no guarantee of fitness for any
particular task. The user assumes full responsibility for its use. Though
the software has been thoroughly tested, the developer is not responsible
for any files that are deleted or damaged through its use.