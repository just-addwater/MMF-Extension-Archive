1000 Global Strings Object
##########################
Jamie Beatson
www.sjinteractive.co.uk
jamie@saintees.com
##########################
The global strings object adds 1000 global strings to your object, and works in the same way as global values

There is only one action, condition, and expression in this object:

Action:
Set Global String

Condition:
Compare two Values

Expression
Get global string

All are easy to use

Any problems e-mail me - jamie@saintees.com

If you can think of anything to add also e-mail me

Thanks
Jamie

