//////////////////////////////////////////////////////////////////////////////
//
// cSurface class
//												

#ifndef _Surface_h
#define _Surface_h

#include "CnpDll.h"

// Forwards
class FAR cSurface;
class FAR cSurfaceImplementation;

// Types
typedef	cSurface FAR * LPSURFACE;

// Blit modes
typedef enum {
	BMODE_OPAQUE,
	BMODE_TRANSP,
	BMODE_MAX
} BlitMode;

// Blit operations
typedef enum {
	BOP_COPY,					// None
	BOP_BLEND,					// dest = ((dest * coef) + (src * (128-coef)))/128
	BOP_INVERT,					// dest = src XOR 0xFFFFFF
	BOP_XOR,					// dest = src XOR dest
	BOP_AND,					// dest = src AND dest
	BOP_OR,						// dest = src OR dest
	BOP_BLEND_REPLACETRANSP,	// dest = ((dest * coef) + ((src==transp)?replace:src * (128-coef)))/128
	BOP_DWROP,
	BOP_ANDNOT,
	BOP_MAX
} BlitOp;

// SetPalette actions
typedef enum
{
	SPA_NONE,					// Just update palette
	SPA_REMAPSURFACE,			// remap current surface pixels to new palette
	SPA_MAX
} SetPaletteAction;

// Surface types
typedef enum SurfaceType
{
	ST_MEMORY,					// Buffer only
	ST_MEMORYWITHDC,			// Buffer + DC (i.e. DIBSection, DDRAW surface, etc...
	ST_MEMORYWITHPERMANENTDC,	// Buffer + permanent DC (i.e. DIBDC)
	ST_MAX
};

// Drivers for memory + DC surfaces
typedef enum MemoryDCSurfaceDriver
{
	SD_DIB,						// DIB (standard driver: DIBSection)
	SD_WING,					// WinG
	SD_DDRAW,					// Direct Draw
	SD_BITMAP,					// Win 3.1 bitmap
	SD_MAX
};

typedef enum LIFlags			// Warning, bit mask, not enumeration!
{
	LI_NONE=0x0000,
	LI_REMAP=0x0001
};

typedef enum SIFlags
{
	SI_NONE=0x0000
};

typedef enum SurfaceError
{
	S_NOERR = 0,
	S_NOTSUPPORTED,
	S_NOTCOMPATIBLE,
	S_NOCONVERSION,
	S_MEMORY_ERROR,
	S_INTERNAL
} SurfaceError;

enum {
	LOCKIMAGE_READBLITONLY,
	LOCKIMAGE_ALLREADACCESS
};

// Convention : SfSrc.FilterBlit(SfDest, MyCallBack, param)
// ==========		pixelDest = MyCallBack(pixelDest, pixelSrc, param)
 	
typedef	COLORREF (CALLBACK * FILTERBLITPROC)(COLORREF, COLORREF, DWORD);
typedef	COLORREF (CALLBACK * MATRIXFILTERBLITPROC)(COLORREF FAR *, COLORREF FAR *, DWORD);

#ifndef WIN32
#define LPCTSTR LPCSTR
#endif

// cSurface class
#ifdef IN_DLL
	#ifdef WIN32
		class FAR __declspec(dllexport) cSurface
	#else
		class __export cSurface
	#endif
#else
	#ifdef WIN32
		class FAR __declspec(dllimport) cSurface
	#else
		class FAR cSurface
	#endif
#endif
{
	public:
		// ======================
		// Creation / Destruction
		// ======================
		cSurface();
		~cSurface();

		// Operators
		cSurface FAR & operator= (cSurface FAR & source);

		// Create surface implementation from surface prototype
		void Create (int width, int height, LPSURFACE prototype);

		// Create pure DC surface from DC
		void Create (HDC hDC);

		// Valid?
		BOOL IsValid ();

		// Clone surface (= create with same size + Blit)
		void Clone (const cSurface FAR & pSrcSurface, int newW = -1, int newH = -1);

		// Delete surface implementation (before to create another one)
		void Delete();

		// ======================
	    // Surface info
		// ======================
		int		GetWidth(void) const;
		int		GetHeight(void) const;
		int		GetDepth(void) const;
		int		GetInfos(int FAR & width, int FAR & height, int FAR & depth) const;

		// ======================
	    // Surface coordinate management
		// ======================

		void	SetOrigin(int x, int y);
		void	SetOrigin(POINT c);

		void	GetOrigin(POINT FAR &pt);
		void	GetOrigin(int FAR & x, int FAR & y);

		void	OffsetOrigin(int dx, int dy);
		void	OffsetOrigin(POINT delta);

		// ======================
	    // Optimize for raster operations
		// ======================
		void	BeginRaster(void);
		void	EndRaster(void);

		// ======================
	    // Device context for graphic operations
		// ======================
		HDC		GetDC(void);
		void	ReleaseDC(HDC dc);

		// ======================
	    // Clipping
		// ======================
		void	GetClipRect(int FAR & x, int FAR & y, int FAR & w, int FAR & h);
		void	SetClipRect(int x, int y, int w, int h);
		void	ClearClipRect(void);

		// ======================
		// LoadImage (DIB format) / SaveImage (DIB format)
		// ======================
		BOOL	LoadImage (HFILE hf, DWORD lsize, LIFlags loadFlags = LI_NONE);
		BOOL	LoadImage (LPCTSTR fileName, LIFlags loadFlags = LI_NONE);
		BOOL	LoadImage (HINSTANCE hInst, int bmpID, LIFlags loadFlags = LI_NONE);
		BOOL	LoadImage (LPBITMAPINFO pBmi, LPBYTE pBits = NULL, LIFlags loadFlags = LI_NONE);
		BOOL	SaveImage (HFILE hf, SIFlags saveFlags = SI_NONE);
		BOOL	SaveImage (LPCTSTR fileName, SIFlags saveFlags = SI_NONE);
		BOOL	SaveImage (LPBITMAPINFO pBmi, LPBYTE pBits, SIFlags saveFlags = SI_NONE);
		DWORD	GetDIBSize ();

		// ======================
		// Pixel functions
		// ======================
		// Set pixel
		BOOL	SetPixel(int x, int y, COLORREF c);
		BOOL	SetPixel(int x, int y, BYTE R, BYTE G, BYTE B);
		BOOL	SetPixel(int x, int y, int index);

		// Get pixel
		BOOL	GetPixel(int x, int y, COLORREF FAR & c) const;
		BOOL	GetPixel(int x, int y, BYTE FAR & R, BYTE FAR & G, BYTE FAR & B) const;
		BOOL	GetPixel(int x, int y, int FAR & index) const;

		// ======================
		// Blit functions
		// ======================
		// Blit surface to surface
		BOOL	Blit(cSurface FAR & dest) const;
		BOOL	Blit(cSurface FAR & dest, int destX, int destY, 
					  BlitMode bm = BMODE_OPAQUE, BlitOp bo = BOP_COPY, DWORD param = 0,
					  int AntiA = 0) const;

		// Blit rectangle to surface
		BOOL	Blit(cSurface FAR & dest, int destX, int destY, 
					  int srcX, int srcY, int srcWidth, int srcHeight,
					  BlitMode bm = BMODE_OPAQUE, BlitOp bo = BOP_COPY, DWORD param = 0,
					  int AntiA = 0) const;

		// Scrolling
		BOOL	Scroll (int xDest, int yDest, int xSrc, int ySrc, int width, int height);

		// Blit via callback
		BOOL	FilterBlit (cSurface FAR & dest, int destX, int destY,
							int srcX, int srcY, int srcWidth, int srcHeight,
							BlitMode bm, FILTERBLITPROC fbProc, DWORD lUserParam) const;

		BOOL	FilterBlit (cSurface FAR & dest, FILTERBLITPROC fbProc, 
			DWORD lUserParam, BlitMode bm = BMODE_OPAQUE) const;

		// Matrix blit via callback
		BOOL	MatrixFilterBlit (cSurface FAR & dest, int destX, int destY,
									int srcX, int srcY, int srcWidth, int srcHeight,
									int mWidth, int mHeight, int mDXCenter, int mDYCenter,
									MATRIXFILTERBLITPROC fbProc, DWORD lUserParam) const;

		// Stretch surface to surface
		BOOL	Stretch(cSurface FAR & dest) const;

		// Stretch surface to rectangle
		BOOL	Stretch(cSurface FAR & dest, int destX, int destY, int destWidth, int destHeight,
						BlitMode bm = BMODE_OPAQUE, BlitOp bo = BOP_COPY, DWORD param = 0) const;

		// Stretch rectangle to rectangle
		BOOL	Stretch(cSurface FAR & dest, int destX, int destY, int destWidth, int destHeight,
						int srcX, int srcY, int srcWidth, int srcHeight,
						BlitMode bm = BMODE_OPAQUE, BlitOp bo = BOP_COPY, DWORD param = 0) const;

		// Revert surface horizontally
		BOOL	ReverseX();

		// Revert rectangle horizontally
		BOOL	ReverseX(int x, int y, int width, int height);

		// Revert surface vertically
		BOOL	ReverseY();

		// Revert rectangle vertically
		BOOL	ReverseY(int x, int y, int width, int height);

		// Remove empty borders
		BOOL	Minimize();
		BOOL	Minimize(RECT FAR* r);

		// ======================
		// Fill
		// ======================
		
		// Fill surface
		BOOL	Fill(COLORREF c);
		BOOL	Fill(int index);
		BOOL	Fill(int R, int G, int B);

		// Fill block
		BOOL	Fill(int x, int y, int w, int h, COLORREF c);
		BOOL	Fill(int x, int y, int w, int h, int index);
		BOOL	Fill(int x, int y, int w, int h, int R, int G, int B);

		// ======================
		// Geometric Primitives
		// ======================

		BOOL	Ellipse(int left, int top, int right, int bottom, int thickness = 1, COLORREF crOutl = BLACK);

		BOOL	Ellipse(int left, int top, int right, int bottom, COLORREF crFill, int thickness = 0, 
			COLORREF crOutl = BLACK, BOOL Fill = TRUE);

		BOOL	Rectangle(int left, int top, int right, int bottom, int thickness = 1, COLORREF crOutl = BLACK);

		BOOL	Rectangle(int left, int top, int right, int bottom, COLORREF crFill, int thickness = 0, 
			COLORREF crOutl = BLACK, BOOL Fill = TRUE);

		BOOL	Polygon(LPPOINT pts, int nPts, int thickness = 1, COLORREF crOutl = BLACK);

		BOOL	Polygon(LPPOINT pts, int nPts, COLORREF crFill, int thickness = 0, 
			COLORREF crOutl = BLACK, BOOL Fill = TRUE);

		BOOL  Line(int x1, int y1, int x2, int y2, int thickness = 1, COLORREF crOutl = BLACK); 

		BOOL	FloodFill(int x, int y, int FAR & left, int FAR & top, int FAR & right, int FAR & bottom, COLORREF crFill, BOOL AntiA = FALSE, 
			int tol = 0, BlitMode bm = BMODE_OPAQUE, BlitOp bo = BOP_COPY, DWORD param = 0);

		BOOL	FloodFill(int x, int y, COLORREF crFill, BOOL AntiA = FALSE,  int tol = 0,
							BlitMode bm = BMODE_OPAQUE, BlitOp bo = BOP_COPY, DWORD param = 0);

		// ======================
		// Rotation
		// ======================
		// Create rotated surface
		BOOL	CreateRotatedSurface (cSurface FAR& ps, double a);
		BOOL	CreateRotatedSurface (cSurface FAR& ps, int a);

		// ======================
		// Text
		// ======================
		int		DrawText (LPSTR text, LPRECT pRc, DWORD dtflags, COLORREF color=0, HFONT hFnt=NULL, 
						  BlitMode bm=BMODE_TRANSP, BlitOp bo=BOP_COPY, DWORD param=0, int AntiA=0);

		// ======================
		// Color / Palette functions
		// ======================
		// Is transparent
		BOOL	IsTransparent();
		
		// Replace color
		BOOL	ReplaceColor (COLORREF newColor, COLORREF oldColor);

	    // Palette support
		BOOL	Indexed(void);
		BOOL	SetPalette(LPLOGPALETTE palette, SetPaletteAction action=SPA_NONE);
		BOOL	SetPalette (cSurface FAR& src, SetPaletteAction action=SPA_NONE);
		BOOL	SetPalette(HPALETTE palette, SetPaletteAction action=SPA_NONE);
		void	Remap(cSurface FAR& src);
		void	Remap(LPBYTE remapTable);
		UINT	GetPaletteEntries(LPPALETTEENTRY paletteEntry, int index, int nbColors);
		int		GetNearestColorIndex(COLORREF rgb);
		COLORREF GetRGB(int index);
		int		GetOpaqueBlackIndex();

	// Private data
	// ------------
	private:
		cSurfaceImplementation FAR *actual;
		POINT						origin;

	protected:
		SurfaceError	error;	// doesn't contain useful info
};

BOOL WINAPI LockImageSurface (LPVOID, WORD hImage, cSurface FAR &cs, int flags=LOCKIMAGE_READBLITONLY);
void WINAPI UnlockImageSurface (cSurface FAR &cs);

// Allocate/Free surface in DLL
LPSURFACE WINAPI DLLExport	NewSurface();
void WINAPI DLLExport		DeleteSurface(LPSURFACE pSurf);

// Get window surface
LPSURFACE WINAPI DLLExport WinGetSurface (int idWin, int reserved=0);

// Get surface prototype
BOOL WINAPI GetSurfacePrototype (LPSURFACE FAR *proto, int depth, SurfaceType st, MemoryDCSurfaceDriver drv);

// maximum opacity
#define OP_MAX 128

#endif	//  _Surface_h
