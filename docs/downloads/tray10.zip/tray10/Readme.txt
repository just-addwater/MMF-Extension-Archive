-----------------------------
Tray Icon Object v1.0
	by Marcello Bastea-Forte, some code pieces by Izzy
-----------------------------

Installation:

* Click & Create/Multimedia Fusion Express
	Copy kctray.cox from the cnc32 directory to your C&C directory
	
* The Games Factory v1.05+
	Copy gftray.gox from the tgf32 directory to your TGF directory
	
* Multimedia Fusion
	Copy kctray.cox from the mmf32 directory to your MMFusion\Program\Extensions directory
	Copy kctray.cox from the mmf32 directory to your MMFusion\Data\Runtime directory
-----------------------------
Examples:

Examples can be found in the example directory.

Example requirements:
* Mini-App (MMF).cca - Requires Window Shape and Window Drag objects, only works on Multimedia Fusion.


-----------------------------
Known bugs:
	* Default icon doesn't show correctly or at all when application is built as an EXE.
		Workaround: load in external icon.
-----------------------------
http://www.cellosoft.com/
http://www.cellosoft.com/extensions/
http://marcello.cellosoft.com/
marcello@cellosoft.com
-----------------------------