Virus Scan Object for IMSI Multimedia Fusion
Beta Release 1 - November 4 , 1999

----------------------------------------------------
INSTALLING VIRUS OBJECT
----------------------------------------------------

What's in the Zip?

1. VSCAN.COX
2. KCDIALOG.COX
3. README.TXT
4. VSCANEX.CCA

Fernando Vivolo made the message box object so thank
him for the great object / extension he has made !

KCDIALOG.COX belongs to him and I used it in the example so
you need to use it to open the example.

VSCAN.COX is mine, it is the main extension object and is required
for the example so don't miss it !

To install the Virus Scan Object follow these simple steps:

1. Unzip all the files to the Programs\Extensions folder located
in your IMSI Multimedia Fusion directory.

2. Unzip all the files to the Data\Runtime folder located in your
IMSI Multimedia Fusion direcotry.

----------------------------------------------------
WHAT DOES THIS OBJECT DO?
----------------------------------------------------

This extension detects viruses in your computer
or shall I say, any computer ! It is easy to use
and configure. Nothing to complex. See the new
example I made and off you go ! If you find any
bugs, email me at: joe_silvo@hotmail.com and
be sure to include the version of IMSI Multimedia
Fusion you are using !

----------------------------------------------------
CAN I SELL MY VIRUS SCANNER MADE WITH 
THE VIRUS SCAN OBJECT?
----------------------------------------------------

Sure, but try and wait until the full version release
comes out because this version may have some
bugs in it !

Enjoy!

Joe Silvo
joe_silvo@hotmail.com