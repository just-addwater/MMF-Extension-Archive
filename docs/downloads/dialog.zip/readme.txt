-----------------
Nemonix Dialog 2.0.1
-----------------
This plugin was created by Christopher Lightfoot. It is FREEWARE and you can use it in your commercial apps.

This plugin allows you to retrieve strings from the user in the form of Dialog Boxes.

Info
----
Created by Christopher Lightfoot
http://www.nemonix.fsnet.co.uk
chris@nemonix.fsnet.co.uk



Conditions
----------
Ok Clicked:		Returns TRUE if the OK button was clicked in the dialog box
Cancel Clicked:		Returns TRUE if the CANCEL button was clicked in the dialog box
			(Both are FALSE at start of frame)

Actions
-------
Application
    Set Main Title	Sets the title of the main application
			Requires a string.
    Set Mouse Pos	Set the X and Y positions of the mouse
			Requires 2 expressions.

Dialogs
    Dialogs
        String Input	Displays a string input dialog
        Value Input	Displays a value input dialog

        Password	Displays a username and password dialog
        Sever Login	Diaplays a server login dialog

	Multi-line	Displays a multilined dialog box

    Set Title		Sets the title of the dialog box
			Requires a string, max 128
    Set Message		Sets the main message
			Requires a string, max 128

Controls
    String 2
        Set Text	The "Server Login" dialog box requires an extra string
			Requires a string, max 128
    Button1
        Enable		Enables button1
        Disable		Disable button1
    Button2
        Enable		Enables button2
        Disable		Disable button2

Resut
    Set EditBox 1:	Sets the string of the editbox1
			Requires a string, max 128
    Set EditBox 2:	Sets the string of the editbox2
			Requires a string, max 128

Expressions
-----------
Strings
	Edit Box 1:	Get the string in the first editbox (top-most)
	Edit Box 2:	Get the string in the second editbox


