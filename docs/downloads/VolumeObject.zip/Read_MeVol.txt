				The Volume Object
				-----------------

------------
Introduction
------------

Most of the volume object is self explanatory, but that which isn't is best understood by understanding the terminology.
If you open up your volume control which usually sits in the system tray, it will help.

SoundCard - Some computers have more than one soundcard, each one has its own set of lines capable of 
	  - transforming digital sound to analog sound or vice-versa.

Line	  - Each sound-card has many lines, one is for transmitting Midi Out sound, one for 
	  - Wave out sound, one for Microphone input, one for overall output to the speakers 
	  - (called the master), and many more.

Controls  - Each line has diffrent controls to alter the sound going through that line. The only
	  - controls that concern the volume object are the volume control and the mute control

Channel	  - Each line has diffrent channels, if there are two channels, a line is said to be Stereo.
	  - If there is only one channel on a line, it is said to be Mono, and if there is more than
	  - 2, a line can be surround sound, quadrophonic or many other names.
	  - Usually if the master line of a soundcard's mixer has 2 channels, all output lines have 
	  - two channels. If you have the volume control for a line, you can set the volume of each
	  - channel seperatly or set them all to the same volume.

This is a sentence that makes sense :
I want to use the volume control on the MIDI Out line for my default soundcard, to set the volume to 0 on all channels. I want that to happen when I press space.

The event to do this is :
� Upon pressing space
: Volume Object->Select Soundcard 0
: Volume Object->Midi Out->Set volume of all channels 0

You should really have the select soundcard 0 action in a start of level event or better still, use the cheque box in the volume object's setup.

---------------------
Questions and Answers
---------------------

Q : Why do I need to select a soundcard?
A : Some computers may have more than one soundcard. Each soundcard has its own volume control

Q : So whats the best way to deal with multiple/single soundcards
A : Soundcard 0 is considered to be a user's default soundcard. You could also create as many volume 
    object's as there are soundcards (There is an expression to get the number of soundcards) then use
    : Volume Object->Spread value A - NumCards( "Volume Object" )
    : Volume Object->Set Soundcard - Alterable value A
    Now any actions you perform on the volume objects will effect all soundcards at once.

Q : What are the five sub-memus, Master, Wave Out, Midi Out, CD, Custom Line?
A : They are what they sound like. Your soundcard doesn't just have one volume control, it has many.
    There is a volume for each diffrent type of output, one for CD, one for MIDI, one for wave audio,
    one to control all outputs at once (The master) and many others which you can access through custom
    line. Open up your volume controller in your system tray to see the diffrent lines you can change.

Q : What is the custom Line?
    The volume object only has the volume controls for the four most common output lines, but you can
    change the custom line to represent any input or output line. For example, setting cutsom line to
    4099 will cause all custom line actions to effect the microphone input line. here is the full list of
    custom line numbers.


DST_DIGITAL     1
DST_LINE        2
DST_MONITOR     3
DST_SPEAKERS    4
DST_HEADPHONES  5
DST_TELEPHONE   6
DST_WAVEIN      7
DST_VOICEIN     8

SRC_DIGITAL     (4096 + 1)
SRC_LINE        (4096 + 2)
SRC_MICROPHONE  (4096 + 3)
SRC_SYNTHESIZER (4096 + 4)
SRC_COMPACTDISC (4096 + 5)
SRC_TELEPHONE   (4096 + 6)
SRC_PCSPEAKER   (4096 + 7)
SRC_WAVEOUT     (4096 + 8)
SRC_AUXILIARY   (4096 + 9)
SRC_ANALOG      (4096 + 10)

Q : What does mute do?
A : When a line is muted, all sound going along that line is blocked.

Q : What is the point of setting the volume of each channel on a line separatly?
A : If an explosion occurs on the left hand side of the screen, you may want the channel 1 (left) 
    to be louder than channel 2 (right).

Q : But if you don't know how many channels the user has, isn't this uselss?
A : You could set the volume of all channels to 0 and then set the volume's of channels 1 and 2.
    There are many ways you could deal with it, if your application really needs diffrent channel
    volumes, you will probably already know what you want to do with the channels other than 1 and 2.

Q : Actually, I'm making a media player. All I want to do is to be able to control the volume without
    disturbing the tilt between left and right (and any other channels)
A : This is why I made proportions. When the volume object has its sound card set (At the start of level
    if you tick the box in object setup), the ratios between each channel volume is recorded in something 
    I call a proportion array. There is a special action under the proportions sub-menu which lets you set
    the volume of a line but keep all the channel volumes under the same ratio as is recorded in the
    proportion array.
    
Q : Can I change the proportions array?
A : Yes there are actions to do this. Each channel has a proportion out of 65535 (2^16-1). If you change its
    propotion, each time you set the volume by proportions, the actual volume each channel is set to is :
    set volume * (proportion/65535)

Q : What are the save and restore control values actions for?
A : You could save values at the start of the level, then restore values at the end of the level. This
    will mean that any changes you make during your game are resetted to normal when the game ends.

Q : What happens if I change the custom line in respect to the above question?
A : The saved values for the old custom line are lost. You should restore the settings just before you change
    the custom line. And then resave if you are trying to preserve the user's volumes. (See example)

Q : Why do you have so many � is available, conditions?
A : You aren't obliged to use them, but you should bear in mind that not everybody has a soundcard.
    The � is mixer available, condition can tell you if the user has a sound card.
    Other is Available conditions tell you if the owners sound card has certain output/input potentials
    For example, you could set the custom line to 4099 and then use the, � is volume control available,
    condition to test if the user has a microphone input.



-------
Queries
-------

If you have a problem with the volume.cox, you should read the questions and answers first!
You can also contact me at theburkeyuk@yahoo.co.uk


