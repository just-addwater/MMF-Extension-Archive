  
			===========================
                                  Time X                    17/06/00
                               ( by z33z )
			===========================


			-=> TABLE OF CONTENTS <=-
			-------------------------

			1.Overview
			2.Installation
			3.Description
			4.Legal Terms
			5.Credits & Contact Info
			6.History
			7.Some words from the author


______________________________________________________________________________
-=> 1. OVERVIEW <=-

Time X is an extension to check the time... :)
______________________________________________________________________________
-=> 2. INSTALLATION <=-

You have to copy the timex.cox into the programs\extension and the 
programs\data\runtime directory of your MMF directory.
That's it.

______________________________________________________________________________
-=> 3. DESCRIPTION <=-
Try it yourself instead!

______________________________________________________________________________
-=> 4. LEGAL TERMS <=-

1) Although Time X has been carefully programmed and thoroughly tested (at least it 
   worked on my computer... :) ) there might occur problems (nobody can tell
   for sure!). If you're using Time X you accept all responsibility for any possible 
   damage that might occur directly or indirectly from its use.

2) You can use Time X in any of your productions for free.

______________________________________________________________________________
-=> 5. CREDITS & CONTACT INFO <=-

If you want to contact me for ANY reason:
(ideas, bug reports, feedback,...)

e-mail:         the_znail@hotmail.com

  
FEEDBACK is very important for me - this is the only way I get to know that 
my efforts are actually not meaningless. Only your feedback will encourage me
to improve Time X and create further extensions.

Please report any errors or problems you ran into while using Time X.
This is the only way I'm actually able to improve Time X. Thanks.

______________________________________________________________________________
-=> 6. HISTORY <=-
First it was only an Every X but in evolved to Time X and now it's more than that. :)

______________________________________________________________________________
-=> 7. SOME WORDS FROM THE AUTHOR <=-



THANKS:
-------
Sephiroth2, Cragmyre and sir flo (I ripped his "readme". :) )

                                                                - z33z -
