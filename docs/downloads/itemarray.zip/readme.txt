Nemonix Item Array - 2.0
---------------------
This extension allows you to store values under names instead of values, so instead of saving to slot 1 you could save to slot "a" or "b"

Actions (The two arrays are seperate arrays)
-------
Set Value		Set a value to an item.
Del Value		Delete an item
Clear			Clears the value array

Set String		Set a string to an item.
Del String		Delete an item
Clear			Clears the string array

Expressions
-----------
Get value		Gets the value of an item
Get String		Gets the string of an item



This plugin was created by christopher lightfoot.
http://www.nemonix.fsnet.co.uk
chris@nemonix.fsnet.co.uk