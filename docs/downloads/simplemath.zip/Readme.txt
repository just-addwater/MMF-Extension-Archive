				Mokhtar M. Khorshid's Simple Math Object
				===================================
Table Of Contents
-----------------
A. Purpose
B. Compatibility
C. Credits
D. About
E. Updates

A. Purpose
---------
This object is used for simple mathematical calculations, like addition and subtraction and can return the greater or smaller value of the parameters sent.

B. Compatibility
----------------
1.The Games Factory
Copy SMath.gox to your TGF folder.

2.Click & Create
Copy SMath.cox to your CNC folder.

3.Multimedia Fusion
Copy SMath.cox to your MMF 'Programs\data\runtime\' folder, and also your MMF 'Programs\Extensions\' folder.

C. Credits
----------
If you used this object in a project please consider giving me credits.

D. About
--------
Created by Mokhtar M. Khorshid of Thunder Power
01/03/00: First version released (1.01)

E. Updates
----------
01/1/2001: MMF conversion by Tim Baker.