CHAIN OBJECT BY 'AKANE'

Includes 
.gox version
.cox version (MMF)
example file (MMF)

Extension seems to be based on INI object...

chain.cca: AMAZING curved lines that bounce with gravity!
Controls: 	Arrow keys, space bar
		Right click and left click!

File written by Tim Baker (and MMF conversion :)