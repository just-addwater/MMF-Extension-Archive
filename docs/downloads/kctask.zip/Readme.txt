WHAT IS KCTASK?
---------------
The KCTASK extension is a task controller you can add to any MMF application.

With KCTASK it's possible to Launch and keep control of other tasks within a MMF 
application.

It's dynamic, you can decide what are applications you get control of, just modifying KCTASK.INI

It's still under development, so please be patient if something does'nt work properly 
or worse, does'nt work at all. 

The safest way to do is... to test it carefully before deploy apps to customers.

This is a "under development" product so at this stage of work, anyone can feel free 
to test, use and distribuite KCTASK.COX at HIS/HER own risk.

There will be a shareware product so if you find it useful for your needs, and want to receive 
full documentation and new versions (when available), please contact me for arrangements.

I will be happy to receive requests, suggestions and even criticism about KCTASK.COX.

HOW IT WORKS
------------
Conditions:

	Is Task Running?

Events:

	Run Task
	Close Task
	Activate Task
	Kill Task by name		(Not currently available)
	Close Task by string		(Not currently available)

Actions:

	TasksRunning
	TaskName$
	TaskExeName$


The KCTASK.INI file
-------------------
KCTASK.COX, uses a file (kctask.ini), in order to retrieve 
info about applications it can command.

The file kctask.ini must be associated with KCTASK object at design-time as follows:
 
double click (or right button click and Edit) on KCTASK object 
set full path for INI file
click OK

EXAMPLE of KCTASK.INI
---------------------

[tasks]
MS Paint=1,c:\programmi\accessori\mspaint.exe
WordPad=2,c:\programmi\accessori\wordpad.exe
MPlayer=3,c:\windows\mplayer.exe
...




the reference to application must follow the sintax:

app_name=app_number,app_exe

where:

app_name is a mnemonic name used to identify task by string
app_number, refers to sequence no. of task (please put them in natural order, as in example)
app_exe, is the full reference of application to be executed


IMPORTANT NOTICE:
KCTASK holds references of tasks it opened and can activate, close, etc. only them.
This means that, at the moment, there is no way to control tasks activated outside of KCTASK.

Alfredo Vasi
e-mail: avasi@nuovetec.com
