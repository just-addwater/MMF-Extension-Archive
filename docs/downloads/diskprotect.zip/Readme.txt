Disk protect


What it does?

Disk protect is an extention that allow you create a diskette to protect your development,
notice that will work on floppies only, that is because is the only way to really protect
a CD from copying at least to unable user to run your programs, games etc..
"Better if your project run from a single diskette".

How come?

In a simple manner you will prepare a diskette with some encryption in some cluster 
(never use cluster 0 it will make disk unusable), after that you may decrypt 
the information you need. using the password action you may save level game,
reach important data and some many stuff.

How the Diskette is a key for my projects ?

the angular stone is to use a diskette that have somes bad clusters, as you see 
this is an individual sucess, the program will read the specific geometry for 
each disk and save it in the cluster you decided it. So when you start your program
just verify the geometry and if this match, we are in bussiness.

How are we sure that it won�t be copyable?

As long as i know all the diskduper in the market are not able to copy a bad sector, 
and even if you mark as a bad sector the extention will check that.

Is the data readable?

the data you saved is encrypted (using set password action) with the key string you defined, "Long is the key 
more difficult to decrypth" 


How to use it?

1.- Prepare the diskette with the diskprotector application, if your are planning 
    to ship with CD you may fill with some dummy data.

2.- If your project come in a diskette find and empty clusters.
    an easy way to do it, make a full defrag to your diskette and use high cluster.

3.- In your application read the disk geometry, if match, ask for data (example a password)

4.- you are responsable to read the data you need (please allways save as string), it means,
    if your password is 16 chars, you should read 16 chars to match.


NOTES:

a.- Each cluster have 512 bytes, so if you are planning to use more than that split in
    several cluster.

b.- Cluster data is not register at the fat tables, so it pass as some garbagge.

c.- You may save text as paragraph, LF/CR  etc.. (use the same way to read)


