				Mokhtar M. Khorshid's Power Object
				==============================
Table Of Contents
-----------------
A. Purpose
B. Compatibility
C. How To Use
D. Caution
E. Credits
F. About
G. Updates

A. Purpose
---------
Calculating powers (WHAT? Just that? Yes).

B. Compatibility
----------------
1.The Games Factory
Copy power.cox to your TGF folder.

2.Click & Create
Copy power.cox to your CNC folder.

3.Multimedia Fusion
Copy power.cox to your MMF 'Programs\data\runtime\' folder, and also your MMF 'Programs\Extensions\' folder.

C. How to use
-------------
Very simple, the only function available (Raise To Power) takes two parameters (Say X & Y), X is the value you want to raise to the power of Y.

D. Caution
----------
Make sure not to use large number as the result may be a very large value.

E. Credits
----------
If you used this object in a project please consider giving me credits.

Special Thanks to V. Inovitch

F. About
--------
"This is my first object ever (So I kept it simple) it took a long time to detect the mistakes that were already in the extension development template (Expresions crashed C&C), but other than that programming the extension was very easy."

Created by Mokhtar M. Khorshid of Thunder Power
19/4/1999: First version released (1.02)

G. Updates
----------
Now there's a square root function, simply pass the value you want its square root to the function and it'll return the square root.

20/4/1999: Version 1.03 released
01/1/2001: MMF conversion by Tim Baker.