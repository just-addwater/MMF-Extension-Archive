###################################################
# Quick Token :: Version 1.3 # 8th July 2003      #
###################################################

Quick Token gets its name for two reasons, firstly it was programmed
very quickly ;) and secondly because it allows you to tokenize a string
with a given delimeter in one expression.

Unlike other extensions that require you to first set the string and/or the
delimeter Quick Token lets you set the string, the delimeter and the token
number you want within a single expression.

Quick Token is a SINGLE CHARACTER tokenizer only. If you use a multiple character
delimeter then the object will tokenize by EACH character in the delimeter. 
NOTE : The tokens are accessed by a ZERO BASED index.

Quick Token is also CASE SENSITIVE. If you do not want a case sensitive delimeter
then for example for the letter "a" use the delimeter "aA" or "Aa" as then the
object will tokenize using both characters.

Quick Token is an MMF only extension, older versions such as TGF do not allow more than
two parameters in an expression hence this extension would not work so dont ask :P
(Use 3EE's String Parser or Cellosoft's Tokenizer instead).

Quick Token also includes a number of other useful expressions for string manipulation:
* Trim, LTrim and RTrim remove space from the beginning or end of the string. 
* Convert string to Upper or Lower case.
* Reverse string.

###################################################
# Changes in Version 1.3 from 1.2		  #
###################################################

* Rebuilt using FireMonkey's SDK reducing size by ~ 50k

###################################################
# Changes in Version 1.2 from 1.1		  #
###################################################

* Action to set how the object reacts to a string containing no delimeters

###################################################
# Changes in Version 1.1 from 1.0		  #
###################################################

* Alteration in the way the GetToken works, used to return the whole string
if the delimeter(s) were not found in the string now it returns "" on this case.

* Added Constants : NewLine, Double Quote, Tab and Copyright

* Added actions to set base as zero or one (for the GetToken expression. Default is zero)

* Negative token no longer returns the first token but returns "" instead

* Added Replace and Remove expressions, again both work on characters but allow multiple
characters to remove/replace example:

- Replace("This is the string","Tig", "hmu") would replace all "T" with "h", all "i" with "m" and 
all "g" with "u" ie ANSWER = "hhms ms the strmnu"

- Remove("This is the string"," is") would remove " ", "i" and "s" ie ANSWER : "Ththetrng"

* Added a remove repeated character expression, you can strip repeats of whatever character(s)
you want such as spaces and "!" ;)

(NOTE BOTH ARE CASE SENSITIVE)


###################################################
# Installation Instructions			  #
###################################################

Copy the directory into your MMF directory structure


###################################################
# Terms of Use 					  #
###################################################

1. This extension is provided free of charge and may be distrubuted as such as long as no 
   charge for the actaul extension is made. If you wish to distribute this extension on a
   CD or other such media with other software please ask the permission of the author.
2. No reverse engineering. YOU MAY NOT MODIFY, TRANSLATE, DISASSEMBLE, OR DECOMPILE 
   THE SOFTWARE, OR ANY COPY, IN WHOLE OR PART.
3. You may use this extensions free of charge in Freeware, Shareware and Commerical
   applications including both exe and ccn files with no proir permission from the author.


###################################################
# Disclaimer :					  #
###################################################

The extension is licensed to you As Is. You, the user, bear the entire risk relating to the quality and performance of the software. In no event will O� Software or the author be liable for direct, indirect, incidental, or consequential damages resulting from any defect in the software. If the software proves to have defects, you, and not O� Software, assume the cost of any necessary service or repair.



###################################################
# Author Details				  #
###################################################

Andrew Mather
andrew@o3software.net
http://www.o3software.net

Icon - Novabrain