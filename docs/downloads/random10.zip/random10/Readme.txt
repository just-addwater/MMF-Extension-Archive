-----------------------------
Randomizer Object v1.0
	by Marcello Bastea-Forte
-----------------------------

Installation:

* Click & Create/Multimedia Fusion Express
	Copy kcrandom.cox from the cnc32 directory to your C&C directory
	
* The Games Factory v1.05+
	Copy gfrandom.gox from the tgf32 directory to your TGF directory
	
* Multimedia Fusion
	Copy kcrandom.cox from the mmf32 directory to your MMFusion\Program\Extensions directory
	Copy kcrandom.cox from the mmf32 directory to your MMFusion\Data\Runtime directory
-----------------------------
http://www.cellosoft.com/
http://www.cellosoft.com/extensions/
http://marcello.cellosoft.com/
marcello@cellosoft.com
-----------------------------