-----------------------------
Mode 7 Object v0.82b
	by Marcello Bastea-Forte
-----------------------------

Installation:

* Multimedia Fusion
	Copy mmf32\mode7.cox from the mmf32 directory to your MMFusion\Program\Extensions directory
	Copy mmf32\runtime\mode7.cox from the mmf32 directory to your MMFusion\Data\Runtime directory

-----------------------------
FAQ:

Q: It's slow!
A: If this extension runs sluggish on your machine, you can speed it up by disabling DirectDraw.  Go to the File Menu, then click Preferences.  There should be two checkboxes for disabling DirectDraw on the first tab.

Q: But, without DirectDraw, I can't go full screen!
A: Read http://www.cellosoft.net/lite/article.php?id=32

Q: It's still slow!
A: Try adjusting the resolution actions.  You can get 3 times the speed with a barely noticable detail difference by setting the resolution to 3x1.

Q: How do I put objects in my game?
A: Use the mapping functions through retrieve data from object.  Try the mode7.cca demo for an example of this in action.

Q: How do I layer the objects properly?
A: At this time there is no way to layer active picture objects (the only way to create resizable images) without an additional extension.  Once Cragmyre's Layer object finishes beta testing, you can use that.

Q: The graphics on the demos are all messed up, the colors are random!
A: For some reason custom-palette gifs don't always work for everyone.  I'm not sure if this is a windows problem, Multimedia Fusions, or something else altogether.  The best workaround for now is to either use a standard windows palette gif or use bmp.


-----------------------------
Examples:

Examples can be found in the examples/ directory. 

Example Notes:

* options.cca
	Requires System Box object.
* stars.cca
	Requires Fast Loop Object

* quasi2.cca
* mode7.cca
* mode7+layer.cca
	Require Active Picture Object

* mode7+layer.cca
	Requires Layer Object v1.04 beta
	
* clouds.gif - by Ravi Sidhu (Gilgamesh)
* tree.gif - by Borne
* blockhead.bmp - by Dustin Friend
	
-----------------------------
http://www.cellosoft.com/
http://www.cellosoft.com/extensions/
http://marcello.cellosoft.com/
marcello@cellosoft.com
-----------------------------