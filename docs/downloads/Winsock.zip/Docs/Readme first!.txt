/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\ Winsock Object 1.0 /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

#include <stddisclaimer.h>
"I, the author of this document and the files you'll find here cannot be held responsible for any harm caused to you, your neighbour, his dog or anything else"

The winsock object is 100% free, do whatever you want with it.

Actions.txt, Conditions.txt, Expressions.txt

These documents explainins how each condition, action and expression works.
To understand some of the text i feel i need to explain things a bit:

When refering to the socket ID number i mean the value you specify when creating the socket
(which must be in the range of 0-99)

When closing a socket, you'll need to create it again to make new connections

If you get alot of errors about "bind" it's probably because another program is already listening on that port

When a client connect to the listening socket, it wont stop listening (if you don't accept the connection with the listening socket of course)

----------------------------------KNOWN BUGS/LIMITATIONS------------------------------------

1. The maximum amount of data you can recieve is 10KB at a time

2. If you get strange (TGF) crashes when using the adress related expressions, it's most likely because you're trying to fit a string longer than 15 bytes in the expressions; save the adress in an invisible edit object first to solve this.




Feel free to mail me about other bugs, suggestions or other useless spam.
			aali@websidorna.com
		   MSN: alan_6666@hotmail.com

EOF